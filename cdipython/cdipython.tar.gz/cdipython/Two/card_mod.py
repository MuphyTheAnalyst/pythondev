#!/usr/bin/env python3
import random

def main():
    deck = create_deck()
    player1_hand = []
    player2_hand = []

    while len(deck) > 0:
        deal_card(player1_hand, deck)
        deal_card(player2_hand, deck)
        print(f"Player 1's hand: {player1_hand}")
        print(f"Player 2's hand: {player2_hand}")

        if calculate_hand_value(player1_hand) > 21 or calculate_hand_value(player2_hand) > 21:
            break

    if calculate_hand_value(player1_hand) > 21 and calculate_hand_value(player2_hand) > 21:
        print("It's a tie. Both players have busted.")
    elif calculate_hand_value(player1_hand) > 21:
        print("Player 2 wins. Player 1 busted.")
    elif calculate_hand_value(player2_hand) > 21:
        print("Player 1 wins. Player 2 busted.")
    else:
        if calculate_hand_value(player1_hand) > calculate_hand_value(player2_hand):
            print("Player 1 wins.")
        elif calculate_hand_value(player2_hand) > calculate_hand_value(player1_hand):
            print("Player 2 wins.")
        else:
            print("It's a tie. Both players have the same score.")

def create_deck():
    return [
        '2 of Spades', '3 of Spades', '4 of Spades', '5 of Spades', '6 of Spades',
        '7 of Spades', '8 of Spades', '9 of Spades', '10 of Spades', 'Jack of Spades',
        'Queen of Spades', 'King of Spades', 'Ace of Spades',
        '2 of Hearts', '3 of Hearts', '4 of Hearts', '5 of Hearts', '6 of Hearts',
        '7 of Hearts', '8 of Hearts', '9 of Hearts', '10 of Hearts', 'Jack of Hearts',
        'Queen of Hearts', 'King of Hearts', 'Ace of Hearts',
        '2 of Clubs', '3 of Clubs', '4 of Clubs', '5 of Clubs', '6 of Clubs',
        '7 of Clubs', '8 of Clubs', '9 of Clubs', '10 of Clubs', 'Jack of Clubs',
        'Queen of Clubs', 'King of Clubs', 'Ace of Clubs',
        '2 of Diamonds', '3 of Diamonds', '4 of Diamonds', '5 of Diamonds', '6 of Diamonds',
        '7 of Diamonds', '8 of Diamonds', '9 of Diamonds', '10 of Diamonds', 'Jack of Diamonds',
        'Queen of Diamonds', 'King of Diamonds', 'Ace of Diamonds'
    ]

def deal_card(hand, deck):
    card = random.choice(deck)
    hand.append(card)
    deck.remove(card)

def calculate_hand_value(hand):
    value = 0
    num_aces = hand.count('Ace of Spades') + hand.count('Ace of Hearts') + hand.count('Ace of Clubs') + hand.count('Ace of Diamonds')

    for card in hand:
        if card.startswith('Ace'):
            value += 11
        elif card.startswith(('King', 'Queen', 'Jack')):
            value += 10
        else:
            value += int(card.split(' ')[0])

    while num_aces > 0 and value > 21:
        value -= 10
        num_aces -= 1

    return value

if __name__ == '__main__':
    main()


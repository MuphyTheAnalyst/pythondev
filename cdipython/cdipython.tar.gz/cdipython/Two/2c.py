#!/usr/bin/env python3
#The file pbnumbers.txt contains the winning lottery numbers selected weekly between
#February 3, 2010 and May 11, 2016. (The file contains 654 sets of winning numbers).
#Each line in the file contains the set of six winning numbers that we selected on a given
#date. The numbers are separated by a space and the last number in each line is the
#complementary number for that day. For example, the first line in the file shows the
#numbers for February 3 2010, which were 17, 22, 36, 37, 52 and the complementary
#number is 24.
#Write a program that will work with this file to search through the file and display the 10
#most common numbers ordered by frequency. The program should then display the 10
#least common numbers 

# Initialize dictionaries to count the occurrences of each number
numbers_count = {}
complementary_count = {}

# Read the lottery numbers from the file
with open('pbnumbers.txt', 'r') as file:
    lines = file.readlines()

for line in lines:
    # Split the line into numbers and the complementary number
    numbers = line.split()[:-1]
    complementary = line.split()[-1]

    # Count occurrences of the main numbers
    for number in numbers:
        if number in numbers_count:
            numbers_count[number] += 1
        else:
            numbers_count[number] = 1

    # Count occurrences of the complementary number
    if complementary in complementary_count:
        complementary_count[complementary] += 1
    else:
        complementary_count[complementary] = 1

# Sort numbers by occurrence in descending order
sorted_numbers = sorted(numbers_count.items(), key=lambda x: x[1], reverse=True)

# Print the 10 most common numbers
print("10 Most Common Main Numbers:")
for number, count in sorted_numbers[:10]:
    print(f"Number: {number}, Occurrences: {count}")

# Sort complementary numbers by occurrence in descending order
sorted_complementary = sorted(complementary_count.items(), key=lambda x: x[1], reverse=True)

# Print the 10 most common complementary numbers
print("\n10 Most Common Complementary Numbers:")
for number, count in sorted_complementary[:10]:
    print(f"Complementary Number: {number}, Occurrences: {count}")

# Print the 10 least common numbers
print("\n10 Least Common Main Numbers:")
for number, count in sorted_numbers[-10:]:
    print(f"Number: {number}, Occurrences: {count}")

# Print the 10 least common complementary numbers
print("\n10 Least Common Complementary Numbers:")
for number, count in sorted_complementary[-10:]:
    print(f"Complementary Number: {number}, Occurrences: {count}")


#!/usr/bin/env python3
try:
    # Read the contents of the "WorldSeriesWinners.txt" file into a list
    with open("WorldSeriesWinners.txt", "r") as file:
        world_series_winners = file.read().splitlines()

    # Ask the user to enter the name of the team
    team_name = input("Enter the name of the team (as it appears in the file): ")
    
    # Initialize a counter to keep track of the team's wins
    team_wins = 0

    # Step through the list to count the team's wins
    for winner in world_series_winners:
        if winner == team_name:
            team_wins += 1

    # Display the number of times the selected team has won the World Series
    if team_wins > 0:
        print(f"{team_name} has won the World Series {team_wins} times.")
    else:
        print(f"{team_name} has not won the World Series from 1903 to 2019.")

except FileNotFoundError:
    print("The file 'WorldSeriesWinners.txt' was not found.")
except Exception as e:
    print(f"An error occurred: {e}")


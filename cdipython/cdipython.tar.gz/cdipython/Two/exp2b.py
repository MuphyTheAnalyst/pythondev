#!/usr/bin/env python3
import matplotlib.pyplot as plt

def read_expenses(expenses_file):
    expenses = {}
    with open(expenses_file, 'r') as file:
        for line in file:
            parts = line.strip().split(": ")
            if len(parts) == 2:
                category, cost = parts
                expenses[category] = float(cost)
            else:
                print(f"Skipping invalid line: {line}")
    return expenses

expenses_data = read_expenses("expenses.txt")


# Prepare data for the pie chart
categories = list(expenses_data.keys())
expenses = list(expenses_data.values())

# Create a pie chart
plt.figure(figsize=(8, 8))
plt.pie(expenses, labels=categories, autopct='%1.1f%%', startangle=140, colors=plt.cm.Paired(range(len(categories))))

# Add a title
plt.title("Monthly Expenses Distribution")

# Show the pie chart
plt.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.

# Save the chart to an image file (optional)
# plt.savefig("expenses_pie_chart.png")

# Display the pie chart
plt.show()


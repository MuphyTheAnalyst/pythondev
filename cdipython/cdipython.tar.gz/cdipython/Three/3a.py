#!/usr/bin/env python3
import tkinter as tk

class AutoServiceApp:
    def __init__(self, root):
        self.root = root
        root.title("Joe's Automotive Services")

        self.total_cost = 0

        # Create Checkbuttons for services
        self.services = {
            'Oil Change': 30.00,
            'Lube Job': 20.00,
            'Radiator Flush': 40.00,
            'Transmission Flush': 100.00,
            'Inspection': 35.00,
            'Muffler Replacement': 200.00,
            'Tire Rotation': 20.00
        }

        self.checkboxes = {}
        for service, cost in self.services.items():
            var = tk.IntVar()
            self.checkboxes[service] = tk.Checkbutton(root, text=service, variable=var)
            self.checkboxes[service].pack()

        # Create Calculate and Quit buttons
        self.calculate_button = tk.Button(root, text="Calculate Charges", command=self.calculate_charges)
        self.calculate_button.pack()

        self.quit_button = tk.Button(root, text="Quit", command=root.quit)
        self.quit_button.pack()

    def calculate_charges(self):
        self.total_cost = 0
        for service, checkbox in self.checkboxes.items():
            if checkbox.cget("variable").get():
                self.total_cost += self.services[service]

        # Create a new window for displaying the total charges
        total_charges_window = tk.Toplevel(self.root)
        total_charges_window.title("Total Charges")

        # Add a label to display the total charges
        total_charges_label = tk.Label(total_charges_window, text=f"Total Charges: ${self.total_cost:.2f}")
        total_charges_label.pack()

if __name__ == '__main__':
    root = tk.Tk()
    app = AutoServiceApp(root)
    root.mainloop()


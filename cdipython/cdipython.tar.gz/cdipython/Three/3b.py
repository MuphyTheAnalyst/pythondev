#!/usr/bin/env python3
#In this code:
#
#    We create a class PropertyTaxCalculator to manage the GUI.
#
#    The user is prompted to enter the actual property value in a text entry field.
#
#    When the "Calculate" button is clicked, the program attempts to convert the entered value to a float and performs the tax calculation.
#
#    If the value is valid, it calculates the assessed value and property tax based on the given formula and displays the result using messagebox.showinfo.
#
#    If the entered value is not numeric, it shows an error message.
#
#You can run this code, enter the actual property value, and click the "Calculate" button to calculate and display the assessed value and property tax.
import tkinter as tk
from tkinter import messagebox

class PropertyTaxCalculator:
    def __init__(self, root):
        self.root = root
        root.title("Winterpeg Property Tax Calculator")

        self.actual_value_label = tk.Label(root, text="Enter Actual Property Value:")
        self.actual_value_label.pack()

        self.actual_value_entry = tk.Entry(root)
        self.actual_value_entry.pack()

        button_frame = tk.Frame(root)  # Create a frame for buttons
        button_frame.pack()

        self.calculate_button = tk.Button(button_frame, text="Calculate", command=self.calculate_tax)
        self.calculate_button.pack(side="left")  # Position "Calculate" button on the left

        self.quit_button = tk.Button(button_frame, text="Quit", command=root.quit)
        self.quit_button.pack(side="left")  # Position "Quit" button on the left

# Create a frame for the footer
        self.footer_frame = tk.Frame(root)
        self.footer_frame.pack()

# Add labels to the footer
        self.footer_label1 = tk.Label(self.footer_frame, text="Property Tax Calculator - © 2023, Designed by: Olajide Usman")
        self.footer_label1.pack()
        
#self.calculate_button = tk.Button(root, text="Calculate", command=self.calculate_tax)
#self.calculate_button.pack()
#self.quit_button = tk.Button(root, text="Quit", command=root.quit)
#self.quit_button.pack()

    def calculate_tax(self):
        try:
            actual_value = float(self.actual_value_entry.get())
            assessed_value = 0.6 * actual_value
            property_tax = (assessed_value / 100) * 0.75
            messagebox.showinfo("Tax Calculation", f"Assessed Value: ${assessed_value:,.2f}\nProperty Tax: ${property_tax:,.2f}")
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid numeric value for the property value.")

if __name__ == '__main__':
    root = tk.Tk()
    app = PropertyTaxCalculator(root)
    root.mainloop()


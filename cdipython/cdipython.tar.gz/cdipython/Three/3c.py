#!/usr/bin/env python3
import tkinter as tk

# Constants for the scale factor and radius of planets (in pixels)
SCALE_FACTOR = 50
PLANET_RADIUS = {
    "Sun": 20,
    "Mercury": 2,
    "Venus": 4,
    "Earth": 4,
    "Mars": 3,
    "Jupiter": 15,
    "Saturn": 13,
    "Uranus": 8,
    "Neptune": 7,
    "Pluto": 1,
}

# Planet colors (you can adjust these)
PLANET_COLORS = {
    "Sun": "yellow",
    "Mercury": "gray",
    "Venus": "orange",
    "Earth": "blue",
    "Mars": "red",
    "Jupiter": "orange",
    "Saturn": "gold",
    "Uranus": "lightblue",
    "Neptune": "blue",
    "Pluto": "gray",
}

# Planet distances (in scaled units)
PLANET_DISTANCES = {
    "Sun": 0,
    "Mercury": 2,
    "Venus": 4,
    "Earth": 6,
    "Mars": 9,
    "Jupiter": 14,
    "Saturn": 20,
    "Uranus": 26,
    "Neptune": 32,
    "Pluto": 36,
}

def draw_planets(canvas):
    for planet, distance in PLANET_DISTANCES.items():
        x = distance * SCALE_FACTOR
        y = 100  # Adjust the Y coordinate as needed
        radius = PLANET_RADIUS[planet]
        color = PLANET_COLORS[planet]

        # Draw the planet as an oval
        canvas.create_oval(x - radius, y - radius, x + radius, y + radius, fill=color)

        # Add a label for the planet
        canvas.create_text(x, y + radius + 10, text=planet)

def main():
    root = tk.Tk()
    root.title("Solar System")

    canvas = tk.Canvas(root, width=500, height=200)  # Adjust the canvas size as needed
    canvas.pack()

    draw_planets(canvas)

    root.mainloop()

if __name__ == "__main__":
    main()


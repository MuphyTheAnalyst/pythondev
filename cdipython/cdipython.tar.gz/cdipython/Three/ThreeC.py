#!/usr/bin/env python3
import tkinter as tk

# Constants for the scale factor and radius of planets (in pixels)
SCALE_FACTOR = 40
PLANET_RADIUS = {
    "Sun": 20,
    "Mercury": 2,
    "Venus": 4,
    "Earth": 4,
    "Mars": 3,
    "Jupiter": 15,
    "Saturn": 13,
    "Uranus": 8,
    "Neptune": 7,
    "Pluto": 1,
}

# Planet colors (you can adjust these)
PLANET_COLORS = {
    "Sun": "yellow",
    "Mercury": "gray",
    "Venus": "orange",
    "Earth": "blue",
    "Mars": "red",
    "Jupiter": "orange",
    "Saturn": "gold",
    "Uranus": "lightblue",
    "Neptune": "blue",
    "Pluto": "gray",
}

# X-coordinates for planets (spaced evenly)
X_COORDINATES = {
    "Sun": 100,
    "Mercury": 200,
    "Venus": 300,
    "Earth": 400,
    "Mars": 500,
    "Jupiter": 600,
    "Saturn": 700,
    "Uranus": 800,
    "Neptune": 900,
    "Pluto": 1000,
}

# Y-coordinate for all planets (on the same horizontal line)
Y_COORDINATE = 200


# Footer text
FOOTER_TEXT = "Solar System Simulation - By Olajide Usman"


def draw_planets(canvas):
    for planet in X_COORDINATES:
        x = X_COORDINATES[planet]
        radius = PLANET_RADIUS[planet]
        color = PLANET_COLORS[planet]

        # Draw the planet as an oval
        canvas.create_oval(x - radius, Y_COORDINATE - radius, x + radius, Y_COORDINATE + radius, fill=color)

        # Add a label for the planet
        canvas.create_text(x, Y_COORDINATE + radius + 10, text=planet)


        

def main():
    root = tk.Tk()
    root.title("Solar System")

    canvas = tk.Canvas(root, width=1200, height=400)
    canvas.pack()

    draw_planets(canvas)

# Create a footer label
    footer_label = tk.Label(root, text=FOOTER_TEXT, font=("Arial", 12))
    footer_label.pack(side="bottom")



    root.mainloop()

if __name__ == "__main__":
    main()


#!/usr/bin/env python3
import tkinter as tk
from tkinter import messagebox

class AutoServiceApp:
    def __init__(self, root):
        self.root = root
        root.title("Joe's Automotive Services")

        self.total_cost = tk.DoubleVar()
        self.check_vars = {}

        # Create Checkbuttons for services
        self.services = {
            'Oil Change': 30.00,
            'Lube Job': 20.00,
            'Radiator Flush': 40.00,
            'Transmission Flush': 100.00,
            'Inspection': 35.00,
            'Muffler Replacement': 200.00,
            'Tire Rotation': 20.00
        }

        for service, cost in self.services.items():
            self.check_vars[service] = tk.IntVar()
            checkbox = tk.Checkbutton(root, text=service, variable=self.check_vars[service])
            checkbox.pack()

        # Create Calculate and Quit buttons
        self.calculate_button = tk.Button(root, text="Calculate Charges", command=self.calculate_charges)
        self.calculate_button.pack()

        self.quit_button = tk.Button(root, text="Quit", command=root.quit)
        self.quit_button.pack()

    def calculate_charges(self):
        self.total_cost.set(0)
        for service, var in self.check_vars.items():
            if var.get() == 1:
                self.total_cost.set(self.total_cost.get() + self.services[service])

        messagebox.showinfo("Total Charges", f"Total Charges: ${self.total_cost.get():.2f}")

if __name__ == '__main__':
    root = tk.Tk()
    app = AutoServiceApp(root)
    root.mainloop()


#!/usr/bin/env python3
# atm_functions.py
import json

class ATMFunctions:
    def __init__(self, filename):
        self.filename = filename

    def load_users(self):
        try:
            with open(self.filename, "r") as file:
                return json.load(file)
        except FileNotFoundError:
            return {}  # Return an empty dictionary if the file doesn't exist

    def save_users(self, data):
        with open(self.filename, "w") as file:
            json.dump(data, file, indent=4)

    def authenticate_user(self, username, pin, users):
        if username in users and users[username]["pin"] == pin:
            return users[username]["balance"]
        return None

    def change_pin(self, username, new_pin, users):
        if username in users:
            users[username]["pin"] = new_pin
            self.save_users(users)

    def deposit(self, username, amount, users):
        if username in users:
            users[username]["balance"] += amount
            self.save_users(users)
            return users[username]["balance"]  # Return the updated balance

    def withdraw(self, username, amount, users):
        if username in users and users[username]["balance"] >= amount:
            users[username]["balance"] -= amount
            self.save_users(users)
            return True, users[username]["balance"]  # Return the updated balance
        return False, None

    def add_user(self, username, pin, users):
        if username not in users:
            users[username] = {"pin": pin, "balance": 0}
            self.save_users(users)
            return True
        return False

    def delete_user(self, username, users):
        if username in users:
            del users[username]
            self.save_users(users)

    def get_balance(self, username, users):
        if username in users:
            return users[username]["balance"]
        return None
    
    

    def exit(self):
        self.main_menu_window.destroy()
        self.main_window.deiconify()

#!/usr/bin/env python3
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from tkinter import simpledialog
from modules.atm_functions import ATMFunctions

class ATM_GUI:
    def __init__(self, root):
        self.root = root
        self.root.title("ATM Simulator")
        self.atm_functions = ATMFunctions("data/users.json")
        self.users = self.atm_functions.load_users()

        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True)

        # Login tab
        self.login_tab = tk.Frame(self.notebook)
        self.notebook.add(self.login_tab, text="Login")
        
        self.username_label = tk.Label(self.login_tab, text="Username:")
        self.username_entry = tk.Entry(self.login_tab)
        self.pin_label = tk.Label(self.login_tab, text="PIN:")
        self.pin_entry = tk.Entry(self.login_tab, show="*")

        self.username_label.pack()
        self.username_entry.pack()
        self.pin_label.pack()
        self.pin_entry.pack()

        self.login_button = tk.Button(self.login_tab, text="Login", command=self.authenticate_user)
        self.login_button.pack()

    def create_gui(self):
        self.atm_tab = tk.Frame(self.notebook)
        self.notebook.add(self.atm_tab, text="ATM Interface")
        self.notebook.select(self.atm_tab)  # Switch to the ATM tab

        self.root.geometry("400x400")

        self.balance_button = tk.Button(self.atm_tab, text="Check Balance", command=self.check_balance)
        self.deposit_button = tk.Button(self.atm_tab, text="Deposit", command=self.deposit)
        self.withdraw_button = tk.Button(self.atm_tab, text="Withdraw", command=self.withdraw)
        self.change_pin_button = tk.Button(self.atm_tab, text="Change PIN", command=self.change_pin)
        self.add_user_button = tk.Button(self.atm_tab, text="Add User", command=self.add_user)
        self.exit_button = tk.Button(self.atm_tab, text="Exit", command=self.exit)

        self.balance_button.pack()
        self.deposit_button.pack()
        self.withdraw_button.pack()
        self.change_pin_button.pack()
        self.add_user_button.pack()
        self.exit_button.pack()

    def authenticate_user(self):
        username = self.username_entry.get()
        pin = self.pin_entry.get()
        balance = self.atm_functions.authenticate_user(username, pin, self.users)
        if balance is not None:
            self.create_gui()
        else:
            messagebox.showerror("Authentication Error", "Invalid username or PIN")

    def check_balance(self):
        username = self.username_entry.get()
        balance = self.atm_functions.get_balance(username, self.users)
    
        if balance is not None:
            # Create a new window to display the balance
            balance_window = tk.Toplevel(self.root)
            balance_window.title("Account Balance")
        
            # Create a label to display the balance
            balance_label = tk.Label(balance_window, text=f"Account Balance for {username}: ${balance:.2f}")
            balance_label.pack()
        else:
            messagebox.showerror("Balance Error", "Invalid username or user not found")

    def deposit(self):
        username = self.username_entry.get()
        amount = simpledialog.askfloat("Deposit", "Enter the amount to deposit:")
        if amount is not None and amount > 0:
            new_balance = self.atm_functions.deposit(username, amount, self.users)
            if new_balance is not None:
                messagebox.showinfo("Deposit", f"Deposited ${amount:.2f}. New balance: ${new_balance:.2f}")
            else:
                messagebox.showerror("Deposit Error", "An error occurred while depositing.")
        else:
            messagebox.showerror("Deposit Error", "Invalid amount")

    def withdraw(self):
        username = self.username_entry.get()
        amount = simpledialog.askfloat("Withdraw", "Enter the amount to withdraw:")
        if amount is not None and amount > 0:
            result, new_balance = self.atm_functions.withdraw(username, amount, self.users)
            if result:
                messagebox.showinfo("Withdrawal", f"Withdrew ${amount:.2f}. New balance: ${new_balance:.2f}")
            else:
                messagebox.showerror("Withdrawal Error", "Insufficient funds")
        else:
            messagebox.showerror("Withdrawal Error", "Invalid amount")

    def change_pin(self):
        username = self.username_entry.get()
        new_pin = simpledialog.askstring("Change PIN", "Enter your new PIN (4 digits):")
        if new_pin is not None and len(new_pin) == 4 and new_pin.isdigit():
            self.atm_functions.change_pin(username, new_pin, self.users)
            messagebox.showinfo("PIN Change", "PIN changed successfully")
        else:
            messagebox.showerror("PIN Change Error", "Invalid PIN format (4 digits required)")

    def add_user(self):
        username = simpledialog.askstring("Add User", "Enter the new username:")
        pin = simpledialog.askstring("Add User", "Enter the new PIN (4 digits):")
        if username is not None and pin is not None and len(pin) == 4 and pin.isdigit():
            success = self.atm_functions.add_user(username, pin, self.users)
            if success:
                messagebox.showinfo("User Added", "New user added successfully")
            else:
                messagebox.showerror("User Addition Error", "Username already exists")
        else:
            messagebox.showerror("User Addition Error", "Invalid input")

    def exit(self):
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = ATM_GUI(root)
    root.mainloop()


#!/usr/bin/env python3
import tkinter as tk
from gui.atm_gui import ATM_GUI  # Update the class name to ATM_GUI
from modules.user import User
from modules.atm_functions import ATMFunctions

class ATMApp:
    def __init__(self, root):
        self.root = root
        root.title("ATM Simulator")
        
        # Create instances of the necessary classes
        self.user = User(username="User1", pin="1234", balance=0)
        self.atm_functions = ATMFunctions(filename="data/users.json")

        # Initialize the GUI
        self.atm_gui = ATM_GUI(root)  # Correct the class name

        # Create a footer label
        footer_label = tk.Label(root, text="ATM Simulator - © 2023 Olajide Usman- CDI College")
        footer_label.pack(side="bottom", fill="both")

if __name__ == '__main__':
    root = tk.Tk()
    app = ATMApp(root)
    root.mainloop()


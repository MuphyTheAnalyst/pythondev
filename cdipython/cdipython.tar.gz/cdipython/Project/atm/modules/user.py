#!/usr/bin/env python3

class User:
    def __init__(self, username="", pin="", balance=0):
        self.username = username
        self.pin = pin
        self.balance = balance

    def to_dict(self):
        return {
            "username": self.username,
            "pin": self.pin,
            "balance": self.balance
        }


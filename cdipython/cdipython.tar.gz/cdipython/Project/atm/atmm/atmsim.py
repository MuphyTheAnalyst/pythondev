#!/usr/bin/env python3
users = [
    {"username": "User1", "pin": "1234", "balance": 1000.00},
    {"username": "User2", "pin": "2222", "balance": 500.50},
    {"username": "User3", "pin": "3333", "balance": 250.75},
]

def authenticate_user(username, pin):
    for user in users:
        if user["username"] == username and user["pin"] == pin:
            return user  # Return the user's information
    return None

def main():
    print("Welcome to the ATM Simulator")
    attempts = 3

    while attempts > 0:
        username = input("Enter your username: ")
        pin = input("Enter your PIN: ")

        user = authenticate_user(username, pin)
        if user:
            print(f"Login successful, Welcome {username}!")

            while True:
                print("\nATM Options:")
                print("1. Check Balance")
                print("2. Withdraw")
                print("3. Deposit")
                print("4. Change PIN")
                print("5. Exit")
                choice = input("Enter your choice (1/2/3/4/5): ")

                if choice == "1":
                    print(f"Account Balance: ${user['balance']:.2f}")
                elif choice == "2":
                    amount = float(input("Enter the amount to withdraw: "))
                    if amount <= 0:
                        print("Invalid amount.")
                    elif amount <= user['balance']:
                        user['balance'] -= amount
                        print(f"Withdrew ${amount:.2f}. New balance: ${user['balance']:.2f}")
                    else:
                        print("Insufficient funds.")
                elif choice == "3":
                    amount = float(input("Enter the amount to deposit: "))
                    if amount > 0:
                        user['balance'] += amount
                        print(f"Deposited ${amount:.2f}. New balance: ${user['balance']:.2f}")
                    else:
                        print("Invalid amount.")
                elif choice == "4":
                    new_pin = input("Enter your new PIN (4 characters): ")
                    if len(new_pin) == 4:
                        user['pin'] = new_pin
                        print("PIN changed successfully.")
                    else:
                        print("Invalid PIN format (4 characters required).")
                elif choice == "5":
                    print("Thank you for using ATM Simulator. Goodbye!")
                    return
                else:
                    print("Invalid choice. Please choose again.")

        else:
            attempts -= 1
            if attempts > 0:
                print(f"Invalid login. {attempts} attempts remaining.")
            else:
                print("Maximum login attempts reached. Goodbye!")

if __name__ == "__main__":
    main()


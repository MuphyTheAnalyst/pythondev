#!/usr/bin/env python3
import json

class ATMFunctions:
    def __init__(self, filename):
        self.filename = filename
        self.users = []

    def load_users(self):
        try:
            with open(self.filename, "r") as file:
                self.users = json.load(file)
        except FileNotFoundError:
            self.users = []

    def save_users(self):
        with open(self.filename, "w") as file:
            json.dump(self.users, file, indent=4)

    def authenticate_user(self, username, pin):
        for user in self.users:
            if user[0] == username and user[1] == pin:
                return user[2]  # Return the balance
        return None

    def change_pin(self, username, new_pin):
        for user in self.users:
            if user[0] == username:
                user[1] = new_pin
                self.save_users()
                return

    def deposit(self, username, amount):
        for user in self.users:
            if user[0] == username:
                user[2] += amount
                self.save_users()
                return user[2]  # Return the updated balance

    def withdraw(self, username, amount):
        for user in self.users:
            if user[0] == username:
                if user[2] >= amount:
                    user[2] -= amount
                    self.save_users()
                    return True, user[2]  # Return the updated balance
                else:
                    return False, None

    def add_user(self, username, pin):
        for user in self.users:
            if user[0] == username:
                return False  # Username already exists
        self.users.append((username, pin, 0))
        self.save_users()
        return True

def main():
    atm_functions = ATMFunctions("data/users.json")
    atm_functions.load_users()

    while True:
        print("\nATM Simulator")
        print("1. Login")
        print("2. Exit")
        choice = input("Enter your choice (1/2): ")

        if choice == "1":
            username = input("Enter your username: ")
            pin = input("Enter your PIN: ")
            balance = atm_functions.authenticate_user(username, pin)
            if balance is not None:
                while True:
                    print("\nATM Options")
                    print("1. Check Balance")
                    print("2. Deposit")
                    print("3. Withdraw")
                    print("4. Change PIN")
                    print("5. Logout")
                    option = input("Enter your choice (1/2/3/4/5): ")

                    if option == "1":
                        print(f"Account Balance: ${balance:.2f}")
                    elif option == "2":
                        amount = float(input("Enter the amount to deposit: "))
                        if amount > 0:
                            new_balance = atm_functions.deposit(username, amount)
                            print(f"Deposited ${amount:.2f}. New balance: ${new_balance:.2f}")
                        else:
                            print("Invalid amount.")
                    elif option == "3":
                        amount = float(input("Enter the amount to withdraw: "))
                        result, new_balance = atm_functions.withdraw(username, amount)
                        if result:
                            print(f"Withdrew ${amount:.2f}. New balance: ${new_balance:.2f}")
                        else:
                            print("Insufficient funds.")
                    elif option == "4":
                        new_pin = input("Enter your new PIN (4 digits): ")
                        if len(new_pin) == 4 and new_pin.isdigit():
                            atm_functions.change_pin(username, new_pin)
                            print("PIN changed successfully.")
                        else:
                            print("Invalid PIN format (4 digits required).")
                    elif option == "5":
                        break
                    else:
                        print("Invalid option. Please choose again.")
        elif choice == "2":
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Please choose again.")

if __name__ == "__main__":
    main()

